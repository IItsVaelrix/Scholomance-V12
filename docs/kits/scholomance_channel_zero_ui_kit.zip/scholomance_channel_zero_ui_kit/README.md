# Scholomance Channel: Zero UI Kit

## Summary

This kit gives the blog a restrained arcane-editorial skin:

- **Hero art:** one controlled cosmic aperture on the side of the page.
- **Post cards:** procedural sigils, not galaxy thumbnails.
- **Visual language:** black glass, cyan signal text, violet rune borders, ivory manuscript typography, gold verdict accents.
- **Implementation style:** scoped CSS tokens and composable React markup.

## Why this direction

Your current page already has a clean foundation. The risk is not “too plain.” The risk is turning the whole surface into space wallpaper. This kit keeps the cosmic motif as a crown-piece and gives everything else a sharper system language: sigils, signal labels, cards, rules, tokens, hover glow, and deterministic layout.

## Files

```txt
assets/
  hero-side-aperture.svg
  sigil-skill.svg
  sigil-postmortem.svg
  sigil-whitepaper.svg
  sigil-verdict.svg
  sigil-origin.svg
  sigil-lexicon.svg
  texture-grid.svg
  texture-grain.svg
  divider-rune.svg

styles/
  scholomance-channel-zero.ui-kit.css

tokens/
  scholomance-channel-zero.tokens.json

components/
  ScholomanceChannelZeroDemo.jsx

preview.html
```

## Integration

1. Copy `assets/` into your public assets folder.
2. Import `styles/scholomance-channel-zero.ui-kit.css`.
3. Wrap the blog route in `.scz-kit`.
4. Use `.scz-hero__art` only for `hero-side-aperture.svg`.
5. Use `.scz-card__sigil` on every transmission card.

## Guardrails

- Do **not** use galaxy backgrounds on cards.
- Do **not** randomize sigils at runtime unless seeded.
- Keep card hover movement under `4px`.
- Keep hero title left-aligned and under `11ch` for the manuscript slab effect.
- Preserve the sticky topbar blur because it gives the page expensive glass without crowding the content.

## QA checklist

- Desktop: hero uses two columns, title remains left readable, side aperture does not swallow the page.
- Tablet: hero art stacks above content, cards become two columns.
- Mobile: nav links collapse by hiding secondary links, cards become one column.
- Reduced motion: hover transitions disable through `prefers-reduced-motion`.
- Accessibility: buttons keep focus ring, decorative sigils use empty alt text.

## Next risks

- Font loading can change perceived pixel alignment. Lock display/body fonts in your app shell.
- If the blog data is dynamic, map post type to a named sigil instead of storing asset paths in individual posts.
- If using Animation AMP, gate shimmer/pulse effects behind reduced-motion and deterministic timing.