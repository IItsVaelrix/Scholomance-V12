import "./scholomance-channel-zero.ui-kit.css";

const transmissions = [
  {
    type: "Skill",
    title: "Signal Origin",
    copy: "Understand the source before you build.",
    className: "",
    sigil: "/assets/sigil-skill.svg",
  },
  {
    type: "Postmortem",
    title: "Algorithmic Complacency",
    copy: "Why creators get lazy and how to break it.",
    className: "scz-card--postmortem",
    sigil: "/assets/sigil-postmortem.svg",
  },
  {
    type: "White Paper",
    title: "The Creative Operating System",
    copy: "A framework for sovereign execution.",
    className: "scz-card--whitepaper",
    sigil: "/assets/sigil-whitepaper.svg",
  },
  {
    type: "Verdict",
    title: "Human > Hype",
    copy: "Tools do not create. Operators do.",
    className: "scz-card--verdict",
    sigil: "/assets/sigil-verdict.svg",
  },
];

export function ScholomanceChannelZeroDemo() {
  return (
    <main className="scz-kit">
      <div className="scz-noise" aria-hidden="true" />

      <header className="scz-topbar">
        <a className="scz-brand" href="/">Scholomance</a>

        <div className="scz-origin" aria-label="Signal origin">
          <div className="scz-origin__signal">Signal Origin 00</div>
          <div className="scz-origin__title">The Scholomance Channel: Zero</div>
        </div>

        <nav className="scz-nav">
          <a href="/blog">Blog</a>
          <a href="/skills">Skills</a>
          <a href="/whitepapers">Whitepapers</a>
          <a href="/verdicts">Verdicts</a>
          <a className="scz-button" href="/subscribe">Subscribe</a>
        </nav>
      </header>

      <section className="scz-hero">
        <div className="scz-hero__content">
          <div className="scz-kicker">The origin feed for creative engineering doctrine</div>
          <h1 className="scz-hero__title">The Scholomance Channel: Zero</h1>
          <div className="scz-hero__rule" />
          <p className="scz-hero__copy">
            Free doctrine for writers, engineers, musicians, and creative operators building their own instruments instead of begging the machine for permission.
          </p>
          <a className="scz-button" href="/skills">Enter the Skills Index</a>
        </div>

        <aside className="scz-hero__art" aria-label="Restrained cosmic hero visual">
          <img src="/assets/hero-side-aperture.svg" alt="" />
        </aside>
      </section>

      <section className="scz-section">
        <div className="scz-section__head">
          <h2 className="scz-section__title"><span>✦</span> Latest Transmissions</h2>
          <p className="scz-section__copy">
            Skills, postmortems, white papers, and verdicts from the creative operating system.
          </p>
        </div>

        <div className="scz-card-grid">
          {transmissions.map((item) => (
            <article className={`scz-card ${item.className}`} key={item.title}>
              <img className="scz-card__sigil" src={item.sigil} alt="" />
              <div className="scz-card__meta">{item.type}</div>
              <h3 className="scz-card__title">{item.title}</h3>
              <p className="scz-card__copy">{item.copy}</p>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}